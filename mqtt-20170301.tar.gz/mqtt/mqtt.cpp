#include <string>
#include <iostream>
#include "mqtt.h"
#include "utils.h"
using namespace std;

int mqttSync::Create(const char* host,const char* port,const char* user,const char* pass)
{
   Connected = 0;
   mHostname = string(host);
   mPort     = string(port);
   mUsername = string(user);
   mPassword = string(pass);
   string addr = mHostname + ":" + mPort;
   mClientID = genUUID(); 
   cerr << "mqtt>> create()" << endl;
   int rc = MQTTClient_create(&mClient, addr.c_str(), mClientID.c_str(), MQTTCLIENT_PERSISTENCE_NONE, NULL);
   if(rc) cerr << "mqtt>> create failed:" << rc << endl;
}

int mqttSync::SetCallbacks(MQTTClient_connectionLost* cl, 		MQTTClient_messageArrived* ma, MQTTClient_deliveryComplete *dc)
{
   cerr << "mqtt>> setCallbacks()" << endl;
   int rc = MQTTClient_setCallbacks(mClient, NULL, cl, ma, dc);
   if(rc) cerr << "mqtt>> setCallbacks failed:" << rc << endl;
}

int mqttSync::Connect()
{
   MQTTClient_connectOptions opts = MQTTClient_connectOptions_initializer;
   opts.username = mUsername.c_str();
   opts.password = mPassword.c_str();
   opts.keepAliveInterval = 10;
   opts.cleansession = 0;

   cerr << "mqtt>> connect()" << endl;
   int rc =  MQTTClient_connect(mClient, &opts); 
   if(rc) cerr << "mqtt>> connect failed:" << rc << endl;
   return rc;
}

void mqttSync::Disconnect()
{
   cerr << "mqtt>> disconnect()" << endl;
   MQTTClient_disconnect(mClient, 10000);
}

void mqttSync::Free()
{
   cerr << "mqtt>> destroy()" << endl;
   MQTTClient_destroy(&mClient);
}

void mqttSync::Subscribe(string topic)
{
   cerr << "mqtt>> subscribe()" << endl;
   int rc = MQTTClient_subscribe(mClient, topic.c_str(), QOS);
   if(rc) cerr << "mqtt>> subscribe failed:" << rc << endl;
}

void mqttSync::Publish(string topic, string payload)
{
   MQTTClient_deliveryToken token;
   MQTTClient_message pubmsg = MQTTClient_message_initializer;
   pubmsg.payload = const_cast<char*>(payload.c_str());
   pubmsg.payloadlen = strlen(payload.c_str());
   pubmsg.qos = QOS;
   pubmsg.retained = 0;
 
   cerr << "mqtt>> publish() len=" << payload.length() << endl;
   int rc = MQTTClient_publishMessage(mClient, topic.c_str(), &pubmsg, &token);
   if(rc) cerr << "mqtt>> publishMessage failed:" << rc << endl;
}

