#include "utils.h"
#include <iostream>
#include <stdlib.h>

using namespace std;

//################################################################################################################
//
//  base64 encoder/decoder
//  string base64_encode(unsigned char const* bytes_to_encode, unsigned int in_len)
//  string base64_decode(string const& encoded_string)
//################################################################################################################
static const std::string base64_chars = 
             "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
             "abcdefghijklmnopqrstuvwxyz"
             "0123456789+/";

static inline bool is_base64(unsigned char c) {
  return (isalnum(c) || (c == '+') || (c == '/'));
}

std::string base64_encode(unsigned char const* bytes_to_encode, unsigned int in_len) {
  std::string ret;
  int i = 0;
  int j = 0;
  unsigned char char_array_3[3];
  unsigned char char_array_4[4];

  while (in_len--) {
    char_array_3[i++] = *(bytes_to_encode++);
    if (i == 3) {
      char_array_4[0] = (char_array_3[0] & 0xfc) >> 2;
      char_array_4[1] = ((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4);
      char_array_4[2] = ((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6);
      char_array_4[3] = char_array_3[2] & 0x3f;

      for(i = 0; (i <4) ; i++)
        ret += base64_chars[char_array_4[i]];
      i = 0;
    }
  }

  if (i)
  {
    for(j = i; j < 3; j++)
      char_array_3[j] = '\0';

    char_array_4[0] = ( char_array_3[0] & 0xfc) >> 2;
    char_array_4[1] = ((char_array_3[0] & 0x03) << 4) + ((char_array_3[1] & 0xf0) >> 4);
    char_array_4[2] = ((char_array_3[1] & 0x0f) << 2) + ((char_array_3[2] & 0xc0) >> 6);
    char_array_4[3] =   char_array_3[2] & 0x3f;

    for (j = 0; (j < i + 1); j++)
      ret += base64_chars[char_array_4[j]];

    while((i++ < 3))
      ret += '=';
  }
  return ret;
}

std::string base64_decode(std::string const& encoded_string) {
  int in_len = encoded_string.size();
  int i = 0;
  int j = 0;
  int in_ = 0;
  unsigned char char_array_4[4], char_array_3[3];
  std::string ret;

  while (in_len-- && ( encoded_string[in_] != '=') && is_base64(encoded_string[in_])) {
    char_array_4[i++] = encoded_string[in_]; in_++;
    if (i ==4) {
      for (i = 0; i <4; i++)
        char_array_4[i] = base64_chars.find(char_array_4[i]);

      char_array_3[0] = ( char_array_4[0] << 2       ) + ((char_array_4[1] & 0x30) >> 4);
      char_array_3[1] = ((char_array_4[1] & 0xf) << 4) + ((char_array_4[2] & 0x3c) >> 2);
      char_array_3[2] = ((char_array_4[2] & 0x3) << 6) +   char_array_4[3];

      for (i = 0; (i < 3); i++)
        ret += char_array_3[i];
      i = 0;
    }
  }

  if (i) {
    for (j = i; j <4; j++)
      char_array_4[j] = 0;

    for (j = 0; j <4; j++)
      char_array_4[j] = base64_chars.find(char_array_4[j]);

    char_array_3[0] = (char_array_4[0] << 2) + ((char_array_4[1] & 0x30) >> 4);
    char_array_3[1] = ((char_array_4[1] & 0xf) << 4) + ((char_array_4[2] & 0x3c) >> 2);
    char_array_3[2] = ((char_array_4[2] & 0x3) << 6) + char_array_4[3];

    for (j = 0; (j < i - 1); j++) ret += char_array_3[j];
  }

  return ret;
}

//################################################################################################################
//  libuuid sample program
//  library install for debian
//      $ sudo apt-get install uuid-dev
//  compile
//      $ gcc uuid_test.c -luuid -o uuid_test
//################################################################################################################
string genUUID()
{
    // typedef unsigned char uuid_t[16];
    uuid_t uuid;
    // generate
    uuid_generate_time_safe(uuid);

    // unparse (to string)
    char uuid_str[37];
    uuid_unparse_lower(uuid, uuid_str);
    //printf("generate uuid=%s\n", uuid_str);
    return string(uuid_str);
}

//################################################################################################################
//  library for file transfer
//################################################################################################################
string makePacketHeader(const char* fname, int total, int seq, string msg, int spos, int size)
{
    char StrValue[16];
    string len;
 
    string ltquote  = "\""; 
    string ltname  = ltquote + "name"  + ltquote; 
    string lttotal = ltquote + "total" + ltquote; 
    string ltseq   = ltquote + "seq"   + ltquote; 
    string ltsize  = ltquote + "size"  + ltquote; 
    string ltdata  = ltquote + "data"  + ltquote;
    
    string header = "{" + ltname  + ":" + ltquote + string(fname) + ltquote + ","; 
    sprintf( StrValue,"%d", total); 
    header += lttotal + ":" + string(StrValue) + ",";
    sprintf( StrValue,"%d", seq); 
    header += ltseq   + ":" + string(StrValue) + ",";
    sprintf( StrValue,"%d", size); 
    header += ltsize   + ":" + string(StrValue) + ",";
    header += ltdata   + ":" + msg.substr(spos,size) + "}";

    return header;                    
}

string getFilename(char* msg)
{
    string fname;
    char* spos = msg+8;
    char* epos = strstr(spos,"\",");
    if(epos != NULL)
     { 
        fname = string(spos, epos-spos);
     } 
    return fname;
}

int AtoI(char* spos, char* epos, int* result)
{
     char  buff[64];
     int len = epos - spos;
     if (len < 1) return -1;

     strncpy(buff, spos, len);
     buff[len]=0;
     *result = atoi(buff);
     return 0;        
}

int getNumber(char* msg)
{
    int number;
    char* newp = strstr(msg,":");
    char* find = strstr(msg,",");
    if(find != NULL)
     { 
        AtoI(newp+1, find, &number);
     } 
    return number;
}

int loadPacketHeader(filePacketHeader& header,char* payload)
{
    string ltquote  = "\""; 
    string ltname  = ltquote + "name"  + ltquote; 
    string lttotal = ltquote + "total" + ltquote; 
    string ltseq   = ltquote + "seq"   + ltquote; 
    string ltsize  = ltquote + "size"  + ltquote; 
    string ltdata  = ltquote + "data"  + ltquote;

    char* find;
    // find name
    find = strstr(payload,ltname.c_str());
    if(find != NULL)
     { 
        header.fname = getFilename(find);
     } 
    else return -1;

    // find total
    find = strstr(payload,lttotal.c_str());
    if(find != NULL)
     { 
        header.total = getNumber(find);
     } 
    else return -1;

    // find seq
    find = strstr(payload,ltseq.c_str());
    if(find != NULL)
     { 
        header.seq = getNumber(find);
     } 
    else return -1;

    // find size
    find = strstr(payload,ltsize.c_str());
    if(find != NULL)
     { 
        header.size = getNumber(find);
     } 
    else return -1;
     
    // find data
    find = strstr(payload,ltdata.c_str());
    if(find != NULL)
     { 
        header.data = find+7;
     } 
    else return -1;
    cout << "   packet total=" << header.total << ", seq=" << header.seq <<endl;

    return 0;                    
}

