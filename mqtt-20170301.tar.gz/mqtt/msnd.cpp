#include <unistd.h>
#include <iostream>
#include <cstdlib>
#include <getopt.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "mqtt.h"
#include "utils.h"

using namespace std;

void OnDelivered(void *context, MQTTClient_deliveryToken dt)
{
   //cout << "msnd>> Delivery confirmed." << endl;
}

int OnReceived(void *context, char *topicName, int topicLen, MQTTClient_message *message)
{
   int  result;
   char* payloadptr;

   payloadptr = (char*)(message->payload);
   cout << ">> Message arrived. topic:" << topicName << endl;
   MQTTClient_freeMessage(&message);
   MQTTClient_free(topicName);
   return 1;
}

void OnDisconnected(void *context, char *cause)
{
   cout << "msnd>> Connection lost. cause:" << cause << endl;
}

//char *dirname(char *path);
//char *basename(char *path);
int publish(mqttSync pub, const char* fname, string msg)
{
    string pubmsg;
    int packetlength = msg.length();
    int packetlimit = 4000;
    int packetcnt = ((packetlength+1) / packetlimit) + 1;
    int ppos, psize;
    
    for (int i=0; i < packetcnt ; i++)
     {
        ppos  = i*packetlimit;
        psize = min(packetlimit, packetlength-ppos);
        pubmsg = makePacketHeader(fname,packetcnt,i+1,msg,ppos,psize );
        pub.Publish("picam/file", pubmsg);
        //cout << "msnd>> Msg sent." << endl;
        //usleep(10);
     }                   
}

int sendFile(mqttSync pub,const char* filepath)
{
    ifstream   infile;
    infile.open(filepath, ios::in|ios::binary);
    if (infile.is_open() == false) return -1;
    streampos startpos = infile.tellg();
    infile.seekg (0, ios::end);
    streampos lastpos  = infile.tellg();

    int fsize = lastpos - startpos;
    char* rbuf = new char[fsize];
    infile.seekg (0, ios::beg);
    infile.read (rbuf, fsize);
    infile.close();

    string encoded = base64_encode((const unsigned char*)rbuf,fsize);
    publish(pub,basename(filepath),encoded);
}

void help(char *argv)
{
    printf("Usage : %s options\n", argv);
    printf("--debug\n--create\n--file [file name]\n--help\n");
}

bool anotherInstanceRunning()
{
   char* fname = (char*)("__single__instance__");
   char  exec[1024];
   strcpy(exec, "ps -a | grep msnd");
   strcat(exec, " > ");
   strcat(exec, fname);   
   strcat(exec, " 2>&1");    // output error to file 
   system(exec);
   
   struct stat fstat;
   stat(fname, &fstat);
   bool rc = false;
   cerr << "msnd>> filesize=" << fstat.st_size << endl;
   // if only one process run, the file size is 29 bytes.
   if(fstat.st_size > 30) rc = true;
   remove(fname);
   return rc;
}

int main(int argc, char* argv[])
{
   int c;
   string fname;
   bool deleteFile = false;

   while (1)
   {
       static struct option long_options[] =
        {
          {"delete", no_argument,        0, 'd'},
          {"file",  required_argument,  0, 'f'},
          {0, 0, 0, 0}
        };
       /* getopt_long stores the option index here. */
       int option_index = 0;
       c = getopt_long (argc, argv, "df:", long_options, &option_index);

       /* Detect the end of the options. */
       if (c == -1)  break;

       switch (c)
       {
          case 0:
            break;

          case 'd':
            deleteFile = true;
            break;
          case 'f':
            fname = string(optarg);
            break;
       }
    }

    cerr << "msnd>> Usage: msnd -d -f filename" << endl;
    if(fname.length() < 3) exit(-1);

    if(anotherInstanceRunning())
    {
        cerr << "msnd>> Another Instance Alreay Running..." << endl;
        exit(-1);
    }

    mqttSync pub;
    pub.Create("m13.cloudmqtt.com","11049","azaufrsp","9oB__BDic_z2"); 
    pub.SetCallbacks(OnDisconnected,OnReceived,OnDelivered);
    int rc = pub.Connect();
    cerr << "msnd>> Connect=" << rc << endl;
    if( rc == 0)
    {
       sendFile(pub, fname.c_str());
       if(deleteFile)  remove( fname.c_str());
       pub.Disconnect();
    }
    
    pub.Free();
    return rc;
}
