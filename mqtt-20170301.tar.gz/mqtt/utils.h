#include <string>
#include <stdio.h>
#include <string.h>
#include <fstream>
#include <uuid/uuid.h>

#define QOS   1
class filePacketHeader
{
    public: 
       std::string fname;
       int    total;
       int    seq;
       int    size;
       char*  data;
}; 

int loadPacketHeader(filePacketHeader& header,char* payload);
std::string makePacketHeader(const char* fname, int total, int seq, std::string msg, int spos, int size);
std::string base64_encode(unsigned char const* , unsigned int len);
std::string base64_decode(std::string const& s);
std::string genUUID();

