#include "stdio.h"
#include "stdlib.h"
#include "MQTTClient.h"

class mqttSync {
   private:
      std::string mHostname;
      std::string mPort;
      std::string mUsername;
      std::string mPassword;
      std::string mClientID; 
      MQTTClient mClient;
      int rc;

   public: 
      int Connected;
      int Create(const char* host,const char* port,const char* user,const char* pass);
      int SetCallbacks(MQTTClient_connectionLost* cl,MQTTClient_messageArrived* ma, MQTTClient_deliveryComplete *dc);
      int  Connect();
      void Publish(std::string topic, std::string payload);
      void Subscribe(std::string topic);
      void Disconnect();
      void Free();
};

