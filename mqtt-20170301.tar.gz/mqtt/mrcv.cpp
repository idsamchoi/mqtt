#include <unistd.h>
#include <iostream>
#include <cstdlib>
#include "mqtt.h"
#include "utils.h"
using namespace std;

FILE*      pFile = NULL;
mqttSync*  mqtt = NULL;
ofstream   outfile;

void OnDelivered(void *context, MQTTClient_deliveryToken dt)
{
   //printf(">> Delivery confirmed.\n");
}

void receiveFile(char* payload)
{
    static filePacketHeader header;
    int rc = loadPacketHeader(header, payload);
    if(rc != 0) {
        cerr << ">> Error Detected..." << endl;
        return;
     }
    if(header.seq == 1) {
       cout << "outfile.open:" << header.fname.c_str() << endl;
       outfile.open(header.fname.c_str(), ios::out|ios::binary);
     }
    if (outfile.is_open() == true) {     
       //cout << "outfile.write:" << header.size << endl;
       string decoded = base64_decode(header.data); 
       outfile.write(decoded.c_str(), decoded.length());
     } 
    if(header.total == header.seq ) {
       cout << "outfile.close:" << endl;
       outfile.close();
     } 
}

int OnReceived(void *context, char *topicName, int topicLen, MQTTClient_message *message)
{
   int  result;
   char* payloadptr;

   payloadptr = (char*)(message->payload);
   cout << ">> topic: " << topicName << endl;
   if(strcmp("picam/file", topicName) == 0)
    {
        receiveFile(payloadptr);       
    }

   MQTTClient_freeMessage(&message);
   MQTTClient_free(topicName);
   return 1;
}

void OnDisconnected(void *context, char *cause)
{
    printf(">> Connection lost. cause: %s.\n", cause);
    if(mqtt != NULL) mqtt->Connect();
}

int Subscribe(mqttSync  &sub)
{ 
    int rc = sub.Connect();
    if( rc == 0)  sub.Subscribe("picam/file");
    return rc;
}

int main(int argc, char* argv[])
{
    mqttSync sub;
    mqtt = &sub;
    sub.Create("m13.cloudmqtt.com","11049","azaufrsp","9oB__BDic_z2"); 
    sub.SetCallbacks(OnDisconnected,OnReceived,OnDelivered);
    Subscribe(sub);
    while(1)
    {
       sleep(50);
    }
    sub.Disconnect();
    sub.Free();
    return 0;
}
